export function HeaderTitle() {
  return <p className="text-black text-3xl font-bold">FindBook</p>;
}
