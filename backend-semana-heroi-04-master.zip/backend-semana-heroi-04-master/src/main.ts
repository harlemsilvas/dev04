import Express from './infra/http/express';

const express = new Express();

express.listen();
