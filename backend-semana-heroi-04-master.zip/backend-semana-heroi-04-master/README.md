[] - cadastrar um livro
[] - update no livro
[] - retornar uma consulta de pesquisa do front 
